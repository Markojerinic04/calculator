import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator {

    private double total1 = 0.0;
    private double total2 = 0.0;

    private char num;
    private JPanel Calculator;
    private JTextField Display;
    private JButton btnEquals;
    private JButton btnMultiply;
    private JButton btnEight;
    private JButton btnNine;
    private JButton btnFive;
    private JButton btnTwo;
    private JButton btnPoint;
    private JButton btnPlus;
    private JButton btnSix;
    private JButton btnThree;
    private JButton btnClear;
    private JButton btnMinus;
    private JButton btnDivide;
    private JButton btnSeven;
    private JButton btnFour;
    private JButton btnOne;
    private JButton btnZero;

    private void getNum(String btnText){
        num = btnText.charAt(0);
        total1 = total1 + Double.parseDouble(Display.getText());
        Display.setText("");
    }

    public Calculator() {
        btnOne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnOneText = Display.getText() + btnOne.getText();
                Display.setText(btnOneText);
            }
        });
        btnTwo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnTwoText = Display.getText() + btnTwo.getText();
                Display.setText(btnTwoText);
            }
        });
        btnThree.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnThreeText = Display.getText() + btnThree.getText();
                Display.setText(btnThreeText);
            }
        });
        btnFour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnFourText = Display.getText() + btnFour.getText();
                Display.setText(btnFourText);
            }
        });
        btnFive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnFiveText = Display.getText() + btnFive.getText();
                Display.setText(btnFiveText);
            }
        });
        btnSix.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnSixText = Display.getText() + btnSix.getText();
                Display.setText(btnSixText);
            }
        });
        btnSeven.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnSevenText = Display.getText() + btnSeven.getText();
                Display.setText(btnSevenText);
            }
        });
        btnEight.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnEightText = Display.getText() + btnEight.getText();
                Display.setText(btnEightText);
            }
        });
        btnNine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnNineText = Display.getText() + btnNine.getText();
                Display.setText(btnNineText);
            }
        });
        btnZero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btnZeroText = Display.getText() + btnZero.getText();
                Display.setText(btnZeroText);
            }
        });
        btnPlus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              String button_text = btnPlus.getText();
              getNum(button_text);
            }
        });
        btnEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String button_text = btnMinus.getText();
                getNum(button_text);
            }
        });
        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                total2 = 0;
                Display.setText("");
            }
        });
        btnPoint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Display.getText().equals("")) {
                    Display.setText("0.");
                }
                else if (Display.getText().contains(".")) {
                    btnPoint.setEnabled(false);
                }
                else{
                    String btnPointText = Display.getText() + btnPoint.getText();
                    Display.setText(btnPointText);
                }
            }
        });


        btnDivide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String divideText = btnDivide.getText();
                getNum(divideText);
            }
        });
        btnMultiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String MultiText = btnMultiply.getText();
                getNum(MultiText);
            }
        });
        btnEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                switch (num)
                {
                    case '+':
                    total2 = total1 + Double.parseDouble(Display.getText());
                    break;
                    case '-':
                        total2 = total1 - Double.parseDouble(Display.getText());
                        break;
                    case '*':
                        total2 = total1 * Double.parseDouble(Display.getText());
                        break;
                    case '/':
                        total2 = total1 / Double.parseDouble(Display.getText());
                        break;

                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculator");
        frame.setContentPane(new Calculator().Calculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
};
